package com.example.pelaporanbencana.model;

public class Menus {
    String id_disasters, disasters_time, disasters_date, disasters_desc, disasters_types;

    public Menus(String id_disasters, String disasters_time, String disasters_date, String disasters_desc, String disasters_types) {
        this.id_disasters = id_disasters;
        this.disasters_time = disasters_time;
        this.disasters_date = disasters_date;
        this.disasters_desc = disasters_desc;
        this.disasters_types = disasters_types;
    }

//    public String getId_disasters() {
//        return id_disasters;
//    }
//
//    public String getDisasters_time() {
//        return disasters_time;
//    }
//
//    public String getDisasters_date() {
//        return disasters_date;
//    }
//
//    public String getDisasters_desc() {
//        return disasters_desc;
//    }
//
//    public String getDisasters_types() {
//        return disasters_types;
//    }
}
