package com.example.pelaporanbencana.model.DisasterUserShowOnProgress;

import com.google.gson.annotations.SerializedName;

public class Data{

    @SerializedName("count")
    private int count;

    public int getCount(){
        return count;
    }
}