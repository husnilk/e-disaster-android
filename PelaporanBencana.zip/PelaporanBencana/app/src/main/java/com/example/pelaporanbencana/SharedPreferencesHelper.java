//package com.example.pelaporanbencana;
//
//import android.content.Context;
//import android.content.SharedPreferences;
//
//public class SharedPreferencesHelper {
//    private SharedPreferences sharedPreferences;
//    private Context context;
////    private String name = "name";
//    private String token = "token";
//
//    public SharedPreferencesHelper(Context context) {
//        this.sharedPreferences = context.getSharedPreferences("login_session", Context.MODE_PRIVATE);
//        this.context = context;
//    }
////
////    public String getName() {
////        return sharedPreferences.getString(name, "");
////    }
////
////    public void setName(String name) {
////        SharedPreferences.Editor edit = sharedPreferences.edit();
////        edit.putString(this.name, name);
////        edit.commit();
////    }
//
//    public String getToken() {
//        return sharedPreferences.getString(token, "");
//    }
//
//    public void setToken(String token) {
//        SharedPreferences.Editor edit = sharedPreferences.edit();
//        edit.putString(this.token, token);
//        edit.commit();
//    }
//}
