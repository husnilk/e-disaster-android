package com.example.pelaporanbencana;

public interface KorbansListener {
    void onKorbansShowAction(Boolean isSelected);
}
